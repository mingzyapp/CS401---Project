import java.io.IOException;

public interface AccountInterface {

    void processCommands() throws IOException;

}